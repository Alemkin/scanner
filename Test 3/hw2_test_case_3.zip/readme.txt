/**************************************
University of Central Florida
COP3404 System Software
**************************************/

HW2 (Scanner)
Test Case 3

There is only one file included: "input_error.txt". 
It has the 4 types of errors that your scanner must detect.

You don't have to report all errors at once: 
as soon as you find an error, report it in the 
console and exit.

To test all error, fix them one by one and 
run the scanner between fixes, so your scanner 
detects the next error. 
