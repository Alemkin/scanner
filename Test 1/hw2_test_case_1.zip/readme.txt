/**************************************
University of Central Florida
COP3404 System Software
**************************************/

HW2 (Scanner)
Test Case 1

This is a simple test case, with a very
basic PL/0 program. This program is 
grammatically correct, but this is not
a requirement for the scanner to work
correctly.
