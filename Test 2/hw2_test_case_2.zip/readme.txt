/**************************************
University of Central Florida
COP3404 System Software
**************************************/

HW2 (Scanner)
Test Case 2

In this test case the input file is not a 
valid PL/0 program, but the scanner must
process it and finish correctly, without 
reporting errors. 

Also note that the comments inside the 
input file should not interfere with the 
scanning process.
